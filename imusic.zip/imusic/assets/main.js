function toggle_menu() {
  // console.log ('be in func.');
  if (document.getElementById('toggle_menu').style.display == 'none') {
    document.getElementById('toggle_menu').style.display = 'block';
  } else {
    document.getElementById('toggle_menu').style.display = 'none';
  }
}

function menu_close() {
  document.getElementById('toggle_menu').style.display = 'none';
}
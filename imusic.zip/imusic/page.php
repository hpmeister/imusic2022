<?php
/* 

page.php

*/


?>
<img src="<?php bloginfo( 'stylesheet_directory' ); ?>/screenshot.png" alt="scsho">